# Technohacks-PythonDevelopment-task9
This repository contains the task 9 that I completed while working as an intern for TECHNOHACKS EDUTECH.  Internship Category - Python Development Internship Duration - 1 Month ( June-2023 ) Internship Type - Work from Home. I was able to complete all tasks successfully within the given time-frame.
